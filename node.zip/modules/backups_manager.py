import sys
import os
import time
import zipfile
from multiprocessing import Process

import mcrcon as mcrcon
import yaml
import shutil
import subprocess
import psutil
from pathlib import Path
import threading
from threading import Thread
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info

def unzip(zip_path, extract_path):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)

def zip_folder(folder_path, zip_path):
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for foldername, subfolders, filenames in os.walk(folder_path):
            for filename in filenames:
                file_path = os.path.join(foldername, filename)
                arcname = os.path.relpath(file_path, folder_path)
                zip_file.write(file_path, arcname)

def list_backups(name):
    path = f'servers/{name}/files'
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    directory = f'backups/{name}'
    folder_list = [folder for folder in os.listdir(directory) if os.path.isdir(os.path.join(directory, folder))]
    return folder_list

def create_backup(name, bp):
    path = f'servers/{name}/files'
    topath = f'backups/{name}/{bp}/{bp}.zip'
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    directory = f'backups/{name}'
    folder_list = [folder for folder in os.listdir(directory) if os.path.isdir(os.path.join(directory, folder))]
    if int(len(folder_list)) >= int(config['servers'][name]['max_backups']):
        return "Max backups."

    os.mkdir(f'backups/{name}/{bp}')
    zip_folder(path, topath)
    return True

def load_backup(name, bp):
    topath = f'servers/{name}/files'
    path = f'backups/{name}/{bp}/{bp}.zip'
    shutil.rmtree(topath)
    unzip(path, topath)
    return True

def remove_backup(name, bp):
    path = f'backups/{name}/{bp}'
    shutil.rmtree(path)
    return True


