import platform
import psutil

ram = psutil.virtual_memory()
ram_total = round(ram.total / (1024 ** 2))

# Получение информации о процессоре (получаем модель процессора)
cpu_info = {
    'name': ' '.join(platform.processor().split()[0:3]),
    'cores': psutil.cpu_count(logical=False),
    'threads': psutil.cpu_count(logical=True),
    'frequency': psutil.cpu_freq().current
}

# Получение информации о диске
disk = psutil.disk_usage('/')
disk_total = round(disk.total / (1024 ** 3))
