import re
import sys
import os
import time
from multiprocessing import Process

import mcrcon as mcrcon
import yaml
import shutil
import subprocess
import psutil
from pathlib import Path
import threading
from threading import Lock

sstarted_lock = Lock()
import re
from threading import Thread
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info

sttop = {}
ccmds = {}
sstarted = []

def thread(func):
    def wrapper(*args, **kwargs):
        threading.Thread(target=func, args=args).start()
    return wrapper

def create_server(owner, name, memory, disk, cpu, port, freezy, rcon, max_backups, cmd):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    path = Path(os.path.join(os.path.dirname(__file__), '..', "servers", name))

    # Проверка на существование папки
    if not path.exists():
        # Создание папки
        path.mkdir(parents=True)
        print(f'Папка {path} успешно создана.')
    else:
        print(f'Папка {path} уже существует.')
        return "Server with this name already exists."
    path2 = Path(os.path.join(os.path.dirname(__file__), '..', "servers", name, "files"))
    path2.mkdir(parents=True)
    path3 = Path(os.path.join(os.path.dirname(__file__), '..', "backups", name))
    path3.mkdir(parents=True)

    if name not in config["servers"]:
        config["servers"][name] = {}  # создаем пустой словарь для этого сервера

    config["servers"][name]['owner'] = owner
    config["servers"][name]['memory'] = memory
    config["servers"][name]['disk'] = disk
    config["servers"][name]['cpu'] = cpu
    config["servers"][name]['port'] = port
    config["servers"][name]['freezy'] = freezy
    config["servers"][name]['cmd'] = cmd
    config["servers"][name]['rconpass'] = rcon
    config["servers"][name]['max_backups'] = max_backups
    config['servers'][name]['started'] = 'false'

    data = {
        'owner': owner,
        'memory': memory,
        'disk': disk,
        'cpu': cpu,
        'port': port,
        'freezy': freezy,
        'cmd': cmd,
        'rconpass': rcon,
        'max_backups': max_backups
    }
    with open(os.path.join(os.path.dirname(__file__), '..', "servers", name, "data.yml"), 'w') as file:
        yaml.dump(data, file, default_flow_style=False)
    with open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), 'w') as file:
        yaml.dump(config, file, default_flow_style=False)
    return True

def edit_server(owner, name, memory, disk, cpu, port, freezy, rcon, max_backups, cmd):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)

    config["servers"][name]['owner'] = owner
    config["servers"][name]['memory'] = memory
    config["servers"][name]['disk'] = disk
    config["servers"][name]['cpu'] = cpu
    config["servers"][name]['port'] = port
    config["servers"][name]['freezy'] = freezy
    config["servers"][name]['cmd'] = cmd
    config["servers"][name]['rconpass'] = rcon
    config["servers"][name]['max_backups'] = max_backups

    data = {
        'owner': owner,
        'memory': memory,
        'disk': disk,
        'cpu': cpu,
        'port': port,
        'freezy': freezy,
        'cmd': cmd,
        'rconpass': rcon,
        'max_backups': max_backups
    }
    with open(os.path.join(os.path.dirname(__file__), '..', "servers", name, "data.yml"), 'w') as file:
        yaml.dump(data, file, default_flow_style=False)
    with open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), 'w') as file:
        yaml.dump(config, file, default_flow_style=False)
    return True

def remove_server(name):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if config['servers'][name]['started'] == 'true':
        forced_stop(name)
    try:
        shutil.rmtree(os.path.join(os.path.dirname(__file__), '..', "servers", name))
        shutil.rmtree(os.path.join(os.path.dirname(__file__), '..', "backups", name))
    except:
        return "Server not found."
    del config["servers"][name]
    with open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), 'w') as file:
        yaml.dump(config, file, default_flow_style=False)
    return True

@thread
def start(cmd, name):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    nn = name
    p = subprocess.Popen("python ../../../starter.py \"" + cmd + "\"", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, cwd=os.path.join(os.path.dirname(__file__), '..', "servers", name, "files"))
    with open(os.path.join(os.path.dirname(__file__), '..', "servers", name, "log.txt"), 'w') as log_file:
        log_file.write("")
    for line in iter(p.stdout.readline, b''):
        time.sleep(0.01)  # здесь задержка, чтобы снизить нагрузку на процессор
        if "INFO]: Rcon connection from: /127.0.0.1" in line.rstrip(): continue
        if name in sttop:
            del sttop[name]
            p.terminate()
        if ']: [Rcon: Stopping the server]' in line.rstrip():
            config['servers'][name]['started'] = 'false'
            with open(os.path.join(os.path.dirname(__file__), "..", "config.yml"), 'w') as file:
                yaml.dump(config, file, default_flow_style=False)
        if name in ccmds:
            p.stdin.write(ccmds[name] + '\n')
            p.stdin.flush()
            del ccmds[name]
        if line.rstrip() == "": continue  # если процесс ничего не выводит (пустая строка)
        with open(os.path.join(os.path.dirname(__file__), '..', "servers", name, "log.txt"), 'a') as log_file:
            log_file.write(line.rstrip() + "\n")
    config['servers'][name]['started'] = 'false'
    with open(os.path.join(os.path.dirname(__file__), "..", "config.yml"), 'w') as file:
        yaml.dump(config, file, default_flow_style=False)

def start_server(name):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if config['servers'][name]['started'] == 'true':
        return 'True'
    config['servers'][name]['started'] = 'true'
    with open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), 'w') as file:
        yaml.dump(config, file, default_flow_style=False)
    ram = config["servers"][name]["memory"]
    disk = config['servers'][name]['disk']
    cpu = config['servers'][name]['cpu']
    freezy = config['servers'][name]['freezy']
    port = config['servers'][name]['port']
    rport = int(port)+1
    owner = config['servers'][name]['owner']
    cmd = config['servers'][name]['cmd']
    rconpass = config['servers'][name]['rconpass']
    with open(os.path.join(os.path.dirname(__file__), '..', "servers", name, "files", "server.properties"), 'w') as f:
        f.write('''
server-port=''' + str(port) + '''
enable-command-block=false
allow-nether=true
rcon.port=''' + str(rport) + '''
rcon.password=''' + str(rconpass) + '''
enable-rcon=true''')

    if freezy == "true":
        return "Freezy error"
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(os.path.join(os.path.dirname(__file__), '..', "servers", name)):
        for filename in filenames:
            filepath = os.path.join(dirpath, filename)
            total_size += os.path.getsize(filepath)

    if total_size / (1024 ** 3) > int(disk):
        return "Disk limit error"
    start(cmd.replace("{memory}", ram), name)
    return True

def send_command(name, command):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if config['servers'][name]['started'] == 'false':
        return "True"
    #with mcrcon.MCRcon("localhost", config['servers'][name]['rconpass'], int(config['servers'][name]['port']) + 1) as rcon:
        # Отправляем команду
        #response = rcon.command(command)
    if 'server.jar' in config['servers'][name]['cmd']:
        with mcrcon.MCRcon("localhost", config['servers'][name]['rconpass'], int(config['servers'][name]['port']) + 1) as rcon:
            response = rcon.command(command)
            with open(f'servers/{name}/log.txt', 'a', encoding='utf-8') as f:
                f.write(re.sub(r'§.', '', response))
            with open(f'servers/{name}/files/logs/latest.txt', 'a', encoding='utf-8') as f:
                f.write(response)
    else:
        ccmds[name] = command

def forced_stop(name):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if config['servers'][name]['started'] == 'false':
        return "True"
    sttop[name] = 'true'

@thread
def updater_1():
    while True:
        config = yaml.load(
            open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
            Loader=yaml.FullLoader)
        for name in config['servers']:
            if config['servers'][name]['started'] == "false":
                with open(f'servers/{name}/log.txt', 'w', encoding='utf-8') as f:
                    f.write("Сервер выключен.")
        time.sleep(3.5)

