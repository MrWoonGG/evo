# node.py
import os

import yaml
from flask import Flask
from routes.connect import connect_blueprint
from routes.create_server import create_server_blueprint
from routes.start_server import start_server_blueprint
from routes.send_command import send_command_blueprint
from routes.fstop_server import fstop_server_blueprint
from routes.remove_server import remove_server_blueprint
from routes.servers_list import servers_list_blueprint
from routes.get_logs import get_logs_blueprint
from routes.create_backup import create_backup_blueprint
from routes.load_backup import load_backup_blueprint
from routes.remove_backup import remove_backup_blueprint
from routes.edit_server import edit_server_blueprint
from routes.get_config import get_config_blueprint
from routes.backups_list import backups_list_blueprint
import modules.servers_manager as server_manager
from flask_cors import CORS

config = yaml.load(
            open(os.path.join(os.path.dirname(__file__), "config.yml"), "r", encoding="utf-8").read().strip(),
            Loader=yaml.FullLoader)
for name in config['servers']:
    config['servers'][name]['started'] = 'false'
    with open(os.path.join(os.path.dirname(__file__), "config.yml"), 'w') as file:
        yaml.dump(config, file, default_flow_style=False)

app = Flask(__name__)
CORS(app)

app.register_blueprint(connect_blueprint, url_prefix='/api')
app.register_blueprint(create_server_blueprint, url_prefix='/api')
app.register_blueprint(start_server_blueprint, url_prefix='/api')
app.register_blueprint(send_command_blueprint, url_prefix='/api')
app.register_blueprint(fstop_server_blueprint, url_prefix='/api')
app.register_blueprint(remove_server_blueprint, url_prefix='/api')
app.register_blueprint(servers_list_blueprint, url_prefix='/api')
app.register_blueprint(get_logs_blueprint, url_prefix='/api')
app.register_blueprint(create_backup_blueprint, url_prefix='/api')
app.register_blueprint(load_backup_blueprint, url_prefix='/api')
app.register_blueprint(remove_backup_blueprint, url_prefix='/api')
app.register_blueprint(edit_server_blueprint, url_prefix='/api')
app.register_blueprint(get_config_blueprint, url_prefix='/api')
app.register_blueprint(backups_list_blueprint, url_prefix='/api')

if __name__ == '__main__':
    server_manager.updater_1()
    app.run(debug=True)


