from flask import Blueprint, jsonify, request
import sys
import os
import yaml
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info
import modules.backups_manager as server_manager

backups_list_blueprint = Blueprint('backups_list', __name__)

@backups_list_blueprint.route('/backups_list/name=<name>;token=<token>')
def get_logs(name, token):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if request.remote_addr != config['allowip']:
        return "Hacker 228)"
    if token != config["token"]:
        print(token)
        return jsonify(status='Access error', message="Invalid token.")

    return server_manager.list_backups(name)