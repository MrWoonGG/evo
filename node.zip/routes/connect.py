# routes/connect.py
from flask import Blueprint, jsonify, request
import sys
import os
import yaml
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info

connect_blueprint = Blueprint('connect', __name__)
config = yaml.load(open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(), Loader=yaml.FullLoader)

@connect_blueprint.route('/connect/ip=<ip>;token=<token>', methods=['GET'])
def connect_route(ip, token):
    if config["ip"] != "None":
        return jsonify(status='Error', message="The node is already attached")
    if ip != request.remote_addr:
        return jsonify(status='Error', message="The machine's IP does not match the IP in the connection request.")
    if token != config["token"]:
        print(token)
        return jsonify(status='Access error', message="Invalid token.")

    config["ip"] = ip
    with open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), 'w') as file:
        yaml.dump(config, file, default_flow_style=False)

    return jsonify(status="True", memory=node_info.ram_total, cpu_name=node_info.cpu_info['name'], cpu_threads=node_info.cpu_info['threads'], cpu_frequency=node_info.cpu_info['frequency'], disk=node_info.disk_total)