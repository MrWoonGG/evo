from flask import Blueprint, jsonify, request
import sys
import os
import yaml
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info
import modules.servers_manager as server_manager

create_server_blueprint = Blueprint('create_server', __name__)

@create_server_blueprint.route('/create_server/owner=<owner>;name=<name>;memory=<memory>;disk=<disk>;cpu=<cpu>;port=<port>;freezy=<freezy>;rconpass=<rcon>;max_backups=<maxbp>;token=<token>', methods=['GET'])
def create_server_route(owner, name, memory, disk, cpu, port, freezy, rcon, maxbp, token):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if request.remote_addr != config['allowip']:
        return "Hacker 228)"
    if token != config["token"]:
        print(token)
        return jsonify(status='Access error', message="Invalid token.")

    r = server_manager.create_server(owner, name, memory, disk, cpu, port, freezy, rcon, maxbp, request.args.get('startup'))
    if r == True:
        return jsonify(status="True", message="Server successfully created.")
    else:
        return jsonify(status="Error", message=r)
