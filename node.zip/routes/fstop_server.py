from flask import Blueprint, jsonify, request
import sys
import os
import yaml
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info
import modules.servers_manager as server_manager

fstop_server_blueprint = Blueprint('fstop_server', __name__)

@fstop_server_blueprint.route("/fstop_server/name=<name>;token=<token>")
def stop_server(name, token):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if token != config["token"]:
        print(token)
        return jsonify(status='Access error', message="Invalid token.")
    if request.remote_addr != config['allowip']:
        return "Hacker 228)"

    server_manager.forced_stop(name)
    return jsonify(status='True', message="Command sended.")
