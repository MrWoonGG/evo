from flask import Blueprint, jsonify, request
import sys
import os
import yaml
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info
import modules.servers_manager as server_manager

get_logs_blueprint = Blueprint('get_logs', __name__)

@get_logs_blueprint.route('/get_logs/name=<name>;token=<token>')
def get_logs(name, token):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if request.remote_addr != config['allowip']:
        return "Hacker 228)"
    if token != config["token"]:
        print(token)
        return jsonify(status='Access error', message="Invalid token.")

    try:
        open("servers/" + name + "/log.txt", 'r', encoding='utf-8').read()
        f = open("servers/" + name + "/log.txt", 'r', encoding='utf-8').read()
    except FileNotFoundError:
        return jsonify(status='Error', message="Logs not found.")
    except UnicodeDecodeError:
        f = open("servers/" + name + "/log.txt", 'r', encoding='cp1251').read()

    return f