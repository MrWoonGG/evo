from flask import Blueprint, jsonify, request
import sys
import os
import yaml

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info
import modules.backups_manager as server_manager

remove_backup_blueprint = Blueprint('remove_backup', __name__)


@remove_backup_blueprint.route('/remove_backup/name=<name>;bp=<bp>;token=<token>', methods=['GET'])
def remove_backup_route(name, bp, token):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if request.remote_addr != config['allowip']:
        return "Hacker 228)"
    if token != config["token"]:
        print(token)
        return jsonify(status='Access error', message="Invalid token.")

    r = server_manager.remove_backup(name, bp)
    if r == True:
        return jsonify(status='True', message="Backup removed.")
    else:
        return jsonify(status='Error', message=r)
