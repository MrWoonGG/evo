from flask import Blueprint, jsonify, request
import sys
import os
import yaml
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info
import modules.servers_manager as server_manager

remove_server_blueprint = Blueprint('remove_server', __name__)
config = yaml.load(open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(), Loader=yaml.FullLoader)

@remove_server_blueprint.route('/remove_server/name=<name>;token=<token>', methods=['GET'])
def remove_server_route(name, token):
    if request.remote_addr != config['allowip']:
        return "Hacker 228)"
    if token != config["token"]:
        print(token)
        return jsonify(status='Access error', message="Invalid token.")

    r = server_manager.remove_server(name)
    if r == True:
        return jsonify(status="True", message="Server successfully removed.")
    else:
        return jsonify(status="Error", message=r)
