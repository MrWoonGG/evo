from flask import Blueprint, jsonify, request
import sys
import os
import yaml
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info
import modules.servers_manager as server_manager

servers_list_blueprint = Blueprint('servers_list', __name__)

@servers_list_blueprint.route('/servers_list/token=<token>')
def servers_list(token):
    if request.remote_addr != config['allowip']:
        return "Hacker 228)"
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if token != config["token"]:
        print(token)
        return jsonify(status='Access error', message="Invalid token.")

    owner = request.args.get('owner', default='none')
    if owner == "none":
        return jsonify(status='True', servers=config['servers'])
    else:
        servers = []
        for server_name, server_config in config.get('servers', {}).items():
            if 'owner' in server_config and server_config['owner'] == owner:
                servers.append({server_name: server_config})
        return jsonify(status='True', servers=servers)