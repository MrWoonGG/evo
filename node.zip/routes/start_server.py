from flask import Blueprint, jsonify, request
import os
import sys
import yaml
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import modules.node_info as node_info
import modules.servers_manager as server_manager

start_server_blueprint = Blueprint('start_server', __name__)

@start_server_blueprint.route("/start_server/name=<name>;token=<token>")
def start_server(name, token):
    config = yaml.load(
        open(os.path.join(os.path.dirname(__file__), '..', "config.yml"), "r", encoding="utf-8").read().strip(),
        Loader=yaml.FullLoader)
    if request.remote_addr != config['allowip']:
        return "Hacker 228)"
    if token != config["token"]:
        print(token)
        return jsonify(status='Access error', message="Invalid token.")


    r = server_manager.start_server(name)
    if r == True:
        return jsonify(status='True', message="Starting...")
    else:
        return jsonify(status='Error', message=r)
