import sys
import os
import threading
import time

cmd = ""


def upd():
    while True:
        time.sleep(0.5)
        print("")


threading.Thread(target=upd).start()

os.system(sys.argv[1])
